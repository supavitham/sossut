import { Component, OnInit } from '@angular/core';
import {AngularFireDatabase,AngularFireObject} from 'angularfire2/database';
import {ActivatedRoute, Router} from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../shared/services/auth.service';
import { Observable } from "rxjs";
import * as firebase from 'firebase';
@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  date = Date.now();
  onClicklogin(){
    console.log("dsf");
      
  }
  constructor(private fb: FormBuilder,private authService: AuthService,private router: Router, private afDb: AngularFireDatabase) { }

  ngOnInit() {
  }
  
}
