import { Component, OnInit } from '@angular/core';
import { AuthService } from "../../shared/services/auth.service";
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { Observable } from "rxjs";
@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css'],

})
export class NotificationComponent implements OnInit {
  
  date = Date.now();
 
  constructor(private authService: AuthService, private afDb: AngularFireDatabase) { 
    
  }
   

  

  ngOnInit() {
  
  }
  
  onClickSignOut(){
    console.log('signOut')
    this.authService.logout();
  }


}
