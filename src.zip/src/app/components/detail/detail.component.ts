import { Component, OnInit } from '@angular/core';
import { AuthService } from "../../shared/services/auth.service";
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { Observable } from "rxjs";
import { GeoService } from '../../shared/services/geo.service'
@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
  lat: number;
  lng: number;
  location: number[];
  markers: any;
  subscription: any;
  lt: Observable<any[]>
  notification: Observable<any>;
  notify: number[];


  constructor(private authService: AuthService, private afDb: AngularFireDatabase,private geo: GeoService) { 
    this.notification = afDb.object("/notification/0001").valueChanges();
    this.lt = afDb.list("/notification/0001/location").valueChanges()
    this.lt.subscribe(
      obj => {
        this.location = obj
        console.log(obj);
        this.getUserLocation()
      }
    );
  }
  

  ngOnInit() {
    this.subscription = this.geo.hits
    .subscribe(hits => this.markers = hits)

    this.notification.subscribe(
      obj => {
        this.notify = obj
        console.log(obj);
      }
    );

    
  }
  ngOnDestroy() {
    this.subscription.unsubscribe()
  }
  private getUserLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
        this.lat = this.location[0] //position.coords.latitude;
        this.lng = this.location[1] //position.coords.longitude;
        /* this.lat = firebase.database().ref().child('lat')
         this.lng = firebase.database().ref().child('lon')*/
        this.geo.getLocations(500, [this.lat, this.lng])
      });
    }
  }

}


