import { NgModule } from '@angular/core';

import { SignUpComponent } from './components/sign-up/sign-up.component';
import { SignInComponent } from './components/sign-in/sign-in.component';
import { DetailComponent } from './components/detail/detail.component';
import { NotificationComponent } from './components/notification/notification.component';
import { NotificationBarComponent } from './components/notification-bar/notification-bar.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { GoogleMapComponent } from './google-map/google-map.component';
import { SigninadminComponent } from './components/signinadmin/signinadmin.component';
import { SignidcardComponent } from './components/signidcard/signidcard.component';
import {Routes,RouterModule} from '@angular/router';

const appRoutes:Routes=[
  {path: 'signin', component: SignInComponent},
  {path: 'welcome', component: WelcomeComponent},
  {path: 'notification', component: NotificationComponent},
  {path: 'NotificationBar', component: NotificationBarComponent},
  {path: 'Detail', component: DetailComponent},
  {path: 'signup', component: SignUpComponent},
  {path: 'googlemap', component: GoogleMapComponent},
  {path: 'signinadmin', component: SigninadminComponent},
  {path: 'signidcard', component: SignidcardComponent},
 // {path: '', component: WelcomeComponent}
  {path: '', redirectTo:'/welcome' , pathMatch:'full'}
  
];
@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
