import { Component, OnInit } from '@angular/core';
import { GeoService } from '../shared/services/geo.service'
import { AngularFireObject, AngularFireDatabase } from 'angularfire2/database';
import { Observable } from 'rxjs';
import * as firebase from 'firebase';

@Component({
  selector: 'app-google-map',
  templateUrl: './google-map.component.html',
  styleUrls: ['./google-map.component.css']
})
export class GoogleMapComponent implements OnInit {
  lat: number;
  lng: number;
  location: number[];
  markers: any;
  subscription: any;
  lt: Observable<any[]>

  constructor(private geo: GeoService, private afDb: AngularFireDatabase) { 
    this.lt = afDb.list("/notification/0001/location").valueChanges()
    this.lt.subscribe(
      obj => {
        this.location = obj
        console.log(obj);
        this.getUserLocation()

      }
    );
    
  }
  ngOnInit() {
     //this.getUserLocation()
     this.subscription = this.geo.hits
     .subscribe(hits => this.markers = hits)
  }
  ngOnDestroy() {
    this.subscription.unsubscribe()
  }
  private getUserLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
        this.lat = this.location[0] //position.coords.latitude;
        this.lng = this.location[1] //position.coords.longitude;
        /* this.lat = firebase.database().ref().child('lat')
         this.lng = firebase.database().ref().child('lon')*/
        this.geo.getLocations(500, [this.lat, this.lng])
      });
    }
  }

}
