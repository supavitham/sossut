export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyD9FVBX69DD5om0uQnMZOYkg__AwE8Ih48",
    authDomain: "sosfirebase-bc120.firebaseapp.com",
    databaseURL: "https://sosfirebase-bc120.firebaseio.com",
    projectId: "sosfirebase-bc120",
    storageBucket: "sosfirebase-bc120.appspot.com",
    messagingSenderId: "1049609704512"
  },
  firebaseConfig:{
      
  },
  googleMapsKey: 'AIzaSyD9FVBX69DD5om0uQnMZOYkg__AwE8Ih48'
};
